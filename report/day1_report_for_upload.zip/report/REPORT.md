# Day 1 Lab Report – Data Overview AI/ML/DL

## Environment
- Runtime: Google Colab – CPU
- Python: 3.13.18
- PyTorch: 2.14.1+cpu
- Ultralytics: 8.4.145
- Models: yolo11n-cls.pt, yolo11n.pt, yolo11n-seg.pt
- Confidence threshold: 0.35
- Changes from source notebook: No changes to model inference settings.

## 1. Image Classification
- Total predictions: 15
- Sample: traffic
- Predicted class: cab
- Class ID: 468
- Confidence: 0.510915
- Taxonomy: ImageNet-1K

Classification predicts labels for the whole image, not object locations.

## 2. Object Detection
- Total predictions: 53
- Sample: kitchen
- Model: yolo11n.pt
- Taxonomy: COCO-80
- Example class: person
- Confidence: 0.912625
- Bounding box (xyxy): [385.33, 69.24, 498.92, 348.92]
- Width: 113.58 pixels
- Height: 279.68 pixels

### Threshold comparison – Kitchen
| Threshold | Number of predictions |
|---|---:|
| 0.20 | 17 |
| 0.35 | 11 |
| 0.60 | 6 |

A bounding box describes an object's position using two corner coordinates.

### Occlusion and truncation
- A foreground person partially hides the oven and sink.
- Hanging cookware overlaps in the image.
- The plant and some objects near image edges are truncated.

## 3. Instance Segmentation
- Total predictions: 49
- Sample: kitchen
- Model: yolo11n-seg.pt
- Taxonomy: COCO-80
- Example class: person
- Instance ID: kitchen-001
- Confidence: 0.899318
- Bounding box: [385.45, 66.44, 498.02, 348.58]
- Polygon point count: 348

Detection locates objects with boxes. Segmentation additionally identifies their pixel-level regions.

### Observed mask issues
- Spoon mask misses part of the handle (under-segmentation).
- Dining table mask extends into the floor and nearby objects (over-segmentation).

## 4. Annotation Lifecycle and Quality Control

| Task | Annotation | Quality check |
|---|---|---|
| Classification | Assign image-level label | Check label matches image |
| Detection | Draw bounding boxes | Check class and box boundaries |
| Segmentation | Draw object masks | Check mask boundaries and overlap |

Use visible object boundaries. Do not guess hidden regions or include background. Review ambiguous labels and heavily occluded objects.

## 5. Data Safety
- Use images only when permitted.
- Avoid exposing personal or sensitive information.
- Keep datasets and outputs in authorized storage.
- Check image attribution and access permissions.

## 6. Submission Checklist
- REPORT.md completed.
- Classification, detection and segmentation JSON files included.
- IMAGE_ATTRIBUTION.md included.
- Three visualization PNG files included.
- Notebook validation should show PASS.
- Repository contains the required report and output folders.
